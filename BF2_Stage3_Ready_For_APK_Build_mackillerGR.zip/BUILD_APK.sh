#!/usr/bin/env bash
# Builds the integrated Stage3 gameapp using an installed Android SDK and Gradle.
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "$ANDROID_HOME" ] || [ ! -f "$ANDROID_HOME/platforms/android-35/android.jar" ]; then
  echo 'ERROR: Android SDK platform 35 missing. Install Android Studio -> SDK Manager -> Android API 35.' >&2
  exit 2
fi
if [ -x ./gradlew ]; then
  GRADLE=./gradlew
elif command -v gradle >/dev/null; then
  GRADLE=gradle
else
  echo 'ERROR: Gradle executable missing (8.9 recommended). Use the included GitHub Actions workflow instead.' >&2
  exit 2
fi
python3 scripts/fetch_sdl_java.py
bash tests/run_stage3.sh
"$GRADLE" :gameapp:assembleDebug --no-daemon
APK=gameapp/build/outputs/apk/debug/gameapp-debug.apk
if [ ! -s "$APK" ]; then echo 'ERROR: APK not produced' >&2; exit 3; fi
if [ -x "$ANDROID_HOME/build-tools/35.0.0/apksigner" ]; then
  "$ANDROID_HOME/build-tools/35.0.0/apksigner" verify "$APK"
fi
printf '\nBUILT: %s\n' "$(realpath "$APK")"
