# Εμπόδια για πλήρες BF2 Android / PC LAN crossplay

**Επιβεβαιωμένο από το mackillerGR/OpenBF2 (`main`, 2026-11-06):**

- `CMakeLists.txt`: υποστηρίζει native builds Windows MSVC x86/x64 και Linux x86_64. Δεν
  υπάρχει ολοκληρωμένο Android client target στο δημόσιο GitHub source.
- `docs/building.md`: `bf2_client` και `SwiffPlayer` γίνονται build ως Windows x86 client.
  Ο strict companion link ελέγχει εκκρεμείς εξωτερικούς συμβολισμούς· διαγνωστικό `/FORCE`
  output από μόνο του δεν σημαίνει playable client.
- `Code/BF2/Menu/SwiffHost.cpp`: η μέθοδος `joinServer(address, port, queryPort)`
  αναζητά λίστα `joinServerLan` και `joinServerInet` και δημοσιεύει event 3.
  Χρησιμοποιεί Win32 includes/συμπεριφορές και περιλαμβάνει `[FRONTIER]` σημεία.
- `Code/BF2/Game/Main/BF2Engine.cpp`: `renderMenu()` καταναλώνει event type 3 και καλεί
  `BF2Engine::joinServer(...)`. `startGame(noAutoJoin, startFromMenu)` έχει διαφορετικό
  μενού/client flow: δεν πρέπει να εξαναγκάζουμε `--level` σε εκκίνηση μενού.
- `Code/BF2/Game/GameClient/GameClient.cpp`: `joinServer()` δημιουργεί `NetClient` και
  ενεργοποιεί δικτυακή σύνδεση. Άλλες client update/load/receive μέθοδοι έχουν FRONTIER.
- `Code/BF2/External/gameswf/SwiffPlayer/SwiffPlayer.cpp`: υπάρχει `swiffFsCommand()`
  που καταγράφει `[FRONTIER]` και τερματίζει (`abort`), άρα η εκκίνηση/χρήση του
  αυθεντικού SWF μενού μπορεί να διακοπεί αν εκτελεστεί αυτή η διαδρομή.
- Στο υπάρχον APK η `GameActivity` είναι **μη exported**. Το companion δεν μπορεί να την
  εκκινήσει με εξωτερικό Intent. Μπορεί μόνο να ανοίξει τη δημόσια `LauncherActivity`.

## Αναγκαίες δοκιμές native πριν πούμε ότι LAN gameplay δουλεύει

1. Από εσωτερική ενσωμάτωση στο **ίδιο BF2 APK**, καταγράψτε τα πραγματικά arguments
   `--menu` / `--connect`. Καταγράψτε το πρώτο native log.
2. Mount `ClientArchives.con` και `Menu_client.zip`, έπειτα menu create/update/render.
   Αν εμφανιστεί FRONTIER, μη το αντικαθιστάτε με αυθαίρετο stub.
3. Σε PC BF2 1.50 server ελεγχόμενο από τον χρήστη, χωρίς PunkBuster, συλλέξτε traces
   από δημιουργία `NetClient`, UDP handshake, disconnect codes και φόρτωση χάρτη.
4. Μετρήστε αν ολοκληρώνεται join / team selection / spawn / chat / gameplay update /
   disconnect / reconnect, όχι μόνο το UDP query στη θύρα 29900.
5. Ελέγξτε checksum/content consistency, edition, version, mods, profile και συγχρονισμό.

**Το tool που υλοποιήθηκε εδώ τερματίζει πριν το βήμα 1:** ολοκληρώνει μόνο discovery,
IP/port selection και μπορεί να ανοίξει τον υπάρχοντα LauncherActivity. Η αποκατάσταση
του native engine απαιτεί πραγματικό SDL3 Android bridge, porting, runtime logs από συσκευή
και αξιόπιστη επαλήθευση του αντίστοιχου πρωτότυπου κώδικα. Δεν υπάρχει γνήσιο
Android gameplay/crossplay στο παραδοτέο.

Πηγές:
- https://github.com/mackillerGR/OpenBF2/blob/main/docs/building.md
- https://github.com/mackillerGR/OpenBF2/blob/main/Code/BF2/Menu/SwiffHost.cpp
- https://github.com/mackillerGR/OpenBF2/blob/main/Code/BF2/Game/GameClient/GameClient.cpp
- https://github.com/mackillerGR/OpenBF2/blob/main/Code/BF2/Game/Main/BF2Engine.cpp
