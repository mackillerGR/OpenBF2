# Test plan — προτεραιότητα LAN

## Πρώτη δοκιμή από Android κινητό και PC

1. Στον υπολογιστή που φιλοξενεί BF2 1.50 LAN server, βρες την IPv4 στο
   `ipconfig` (π.χ. `192.168.1.100`). Σύνδεσε το Android στο ίδιο LAN/Wi-Fi
   χωρίς guest isolation / client isolation.
2. Βεβαιώσου ότι το BF2 PC server απαντά σε UDP query. Η συνήθης game port
   είναι 16567 και η GameSpy query port 29900, αλλά αυτές μπορούν να διαφέρουν.
   Στο firewall του PC επέτρεψε μόνο όσα χρειάζονται στο **ιδιωτικό LAN**.
3. Με το Stage2 Android companion πατάς «Έλεγχος της συγκεκριμένης IP».
   Αν ο server απαντήσει, η εφαρμογή εμφανίζει IP, map, players και `hostport`.
   Αν το broadcast δεν εμφανίσει server, χρησιμοποίησε την ακριβή IP.
4. Πατάς «Αντιγραφή IP:gameport» και «Άνοιγμα Battlefield 2 test13». Στο
   παλιό launcher επίλεξε τις ρυθμίσεις του παιχνιδιού και βάλε το αντιγραμμένο
   IP:port στο πεδίο «Διακομιστής». Το `test13` μπορεί ακόμη να μην κάνει join.
5. Για αρχικό μενού, στο `test13` επίλεξε «Έναρξη» (με `--menu`), όχι forced map.
   Αν ανοίξει απευθείας πίστα, θα πρέπει να διορθωθεί η native εκκίνηση.
6. Εάν αποτύχει, εξήγαγε το `openbf2.log` από τον παλιό launcher ή συλλογή
   `adb logcat` και στείλε το για να εντοπιστεί η ακριβής αιτία.

## Έλεγχοι ανάπτυξης σε PC (χωρίς Android SDK)

```bash
bash tests/run_all.sh
python scripts/bf2_lan_probe.py 192.168.1.100
```

Το τεστ δημιουργεί loopback fake GameSpy server για απομόνωση του πρωτοκόλλου.
Δεν είναι BF2 game server ούτε απόδειξη σύνδεσης παιχνιδιού.

## Build Android Companion (σε μηχάνημα με Android Studio / SDK)

Άνοιξε τον φάκελο `BF2_Android_LAN_Stage2` ως Gradle project.
Απαιτούνται JDK 17, Gradle 8.9, Android SDK Platform 35, Android build tools.
Μετά τον Gradle sync χτίσε `:app:assembleDebug`.
Το project **δεν έχει bundled Gradle wrapper ή Android SDK**.
Η προαιρετική GitHub Actions workflow μπορεί να χτίσει το ανεξάρτητο companion
όταν το project ανέβει ως root ξεχωριστού repository. Δεν έγινε CI run εδώ.

**Δεν ενσωματώνεται μέσα στο BF2 APK**: διαφορετικό package ID, καμία αλλαγή στο `test13`.
Η `GameActivity` του test13 δεν είναι exported και δεν μπορεί να κληθεί από το companion.
