#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
javac -encoding UTF-8 -d "$BUILD" \
    "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanQuery.java" \
    "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanJoinArgs.java" \
    "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanDiscovery.java" \
    "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanLaunchPlan.java" \
    "$ROOT/tests/LanStage2Test.java" \
    "$ROOT/tests/LanQueryTest.java"
java -cp "$BUILD" LanStage2Test
java -cp "$BUILD" LanQueryTest
(cd "$ROOT" && python -m unittest discover -s tests -v)
python -m py_compile "$ROOT/scripts/bf2_lan_probe.py"
javac -encoding UTF-8 -d "$BUILD" "$ROOT/tests/ParseAndroidSources.java"
java -cp "$BUILD" ParseAndroidSources \
    "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanProbeActivity.java"
python - "$ROOT" <<'PY'
import pathlib,sys,xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]);m=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
assert m.tag=='manifest'
print('PASS Android Manifest XML parses')
PY
