import importlib.util
import json
from pathlib import Path
import socket
import threading
import unittest

modulepath = Path(__file__).resolve().parents[1] / 'scripts' / 'bf2_lan_probe.py'
spec = importlib.util.spec_from_file_location('bf2_lan_probe', modulepath)
import sys
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

class BF2LanProbeTests(unittest.TestCase):
    def test_request_exact_wire_format(self):
        self.assertEqual(module.make_request(b'\x01\x02\x03\x04'),
                         bytes.fromhex('fe fd 00 01 02 03 04 ff 00 00 00'))

    def test_basic_split_reply(self):
        token = b'\x11\x22\x33\x44'
        packet = b'\x00' + token + b'splitnum\x00\x80\x00hostname\x00BF2 LAN\x00hostport\x0016567\x00numplayers\x003\x00maxplayers\x0016\x00\x00'
        actual = module.parse_response(packet, token)
        self.assertEqual(actual['hostname'], 'BF2 LAN')
        self.assertEqual(actual['hostport'], '16567')
        self.assertEqual(module.summarize('192.168.1.2',29900,actual).game_port,16567)

    def test_reject_wrong_token(self):
        with self.assertRaises(ValueError):
            module.parse_response(b'\x00\x00\x00\x00\x00hostname\x00Server\x00', b'\x01\x02\x03\x04')

    def test_empty_fields(self):
        with self.assertRaises(ValueError):
            module.parse_response(b'\x00abcd\x00', b'abcd')

    def test_fake_local_server(self):
        ready = threading.Event()
        result = {}
        def server():
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.bind(('127.0.0.1', 0))
                result['port'] = s.getsockname()[1]
                ready.set()
                data, addr = s.recvfrom(500)
                self.assertEqual(data[:3], b'\xfe\xfd\x00')
                reply = b'\x00' + data[3:7] + b'splitnum\x00\x80\x00hostname\x00LAN Test\x00hostport\x0016567\x00mapname\x00Strike at Karkand\x00\x00'
                s.sendto(reply, addr)
        thread = threading.Thread(target=server, daemon=True)
        thread.start()
        self.assertTrue(ready.wait(2))
        found = module.query_servers('127.0.0.1', result['port'], timeout=0.8)
        thread.join(timeout=2)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].map_name, 'Strike at Karkand')

    def test_gameport_invalid_falls_back(self):
        info = module.summarize('127.0.0.1', 29900, {'hostport':'abc'})
        self.assertEqual(info.game_port, 16567)

if __name__ == '__main__': unittest.main()
