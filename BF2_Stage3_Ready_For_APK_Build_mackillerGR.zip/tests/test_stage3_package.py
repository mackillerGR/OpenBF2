"""Offline sanity tests for the integrated Stage3 project (not an Android build)."""
import pathlib
import re
import unittest
import xml.etree.ElementTree as ET
from scripts.fetch_sdl_java import git_blob_sha

ROOT = pathlib.Path(__file__).resolve().parents[1]
JAVA = ROOT / 'gameapp/src/main/java/com/mackillergr/bf2'
NATIVE = ROOT / 'gameapp/src/main/jniLibs/arm64-v8a'
NAMES = ['c++_shared','SDL3','dice_py','dxvk_d3d9','vkd3d-shader','main']

class Stage3(unittest.TestCase):
    def test_valid_manifest(self):
        root = ET.parse(ROOT/'gameapp/src/main/AndroidManifest.xml').getroot()
        uri = '{http://schemas.android.com/apk/res/android}'
        self.assertEqual(root.tag,'manifest')
        activities = [x.attrib[uri+'name'] for x in root.findall('.//activity')]
        self.assertIn('com.mackillergr.bf2.LauncherActivity',activities)
        self.assertIn('com.mackillergr.bf2.GameActivity',activities)
        self.assertIn('com.mackillergr.bf2.LanBrowserActivity',activities)
    def test_library_load_order_from_test13_dex(self):
        java=(JAVA/'GameActivity.java').read_text()
        m=re.search(r'new String\[\]\s*\{(.*?)\}',java,re.S)
        self.assertIsNotNone(m)
        found=re.findall(r'"([^"]+)"',m.group(1))
        self.assertEqual(NAMES,found)
    def test_native_libraries_present(self):
        self.assertEqual(len(list(NATIVE.glob('*.so'))),15)
        self.assertGreater((NATIVE/'libmain.so').stat().st_size,1_000_000)
        self.assertIn(b'SDL-3.4.14',(NATIVE/'libSDL3.so').read_bytes())
    def test_sdl_fingerprint_helper(self):
        self.assertEqual(git_blob_sha(b'hello'), 'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')

if __name__=='__main__': unittest.main()
