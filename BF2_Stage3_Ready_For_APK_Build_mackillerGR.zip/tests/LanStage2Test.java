import com.mackillergr.bf2.lan.LanDiscovery;
import com.mackillergr.bf2.lan.LanJoinArgs;
import com.mackillergr.bf2.lan.LanLaunchPlan;
import com.mackillergr.bf2.lan.LanQuery;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class LanStage2Test {
    static int count = 0;
    static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
        count++;
        System.out.println("PASS " + name);
    }

    static byte[] reply(byte[] token) {
        byte[] body = ("hostname\0LAN Server\0mapname\0Strike_at_Karkand\0hostport\0" +
                "16567\0gamever\01.5\0numplayers\02\0maxplayers\016\0\0")
                .getBytes(StandardCharsets.ISO_8859_1);
        byte[] packet = new byte[5 + body.length];
        System.arraycopy(token, 0, packet, 1, 4);
        System.arraycopy(body, 0, packet, 5, body.length);
        return packet;
    }

    static void testLaunch() {
        LanLaunchPlan menu = LanLaunchPlan.menu("/storage/emulated/0/BF2/Game Files/mods/bf2", 1920, 1080, "mackillerGR");
        check(Arrays.asList(menu.arguments).contains("--menu"), "menu mode includes --menu");
        check(!Arrays.asList(menu.arguments).contains("--level"), "menu mode has no forced level");
        LanLaunchPlan lan = LanLaunchPlan.directLan("/storage/emulated/0/BF2/Game Files/mods/bf2", 1280, 720,
                "Player1", "192.168.1.100", 16567);
        List<String> args = Arrays.asList(lan.arguments);
        check(args.contains("--connect") && args.contains("192.168.1.100:16567"), "LAN mode uses proper direct IP");
        check(!args.contains("--hosted") && !args.contains("--menu"), "LAN mode has no forced host or menu");
        String[] cleaned = LanJoinArgs.directIp(new String[] {"--mod", "/a", "--menu", "--level", "X", "--connect", "1.2.3.4:111"}, "10.0.0.2", 20000);
        check(Arrays.asList(cleaned).contains("--mod") && !Arrays.asList(cleaned).contains("X") &&
                !Arrays.asList(cleaned).contains("1.2.3.4:111"), "replace mode-specific args safely");
        boolean rejected = false;
        try { LanLaunchPlan.directLan("/mod", 1280, 720, "Player", "192.168.1.300", 16567); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected, "reject invalid IP");
        rejected = false;
        try { LanLaunchPlan.menu("/mod", 200, 100, "Player"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected, "reject invalid resolution");
    }

    static void testDiscoveryFixture() throws Exception {
        final AtomicReference<Throwable> serverError = new AtomicReference<>();
        try (DatagramSocket mock = new DatagramSocket(0, InetAddress.getByName("127.0.0.1"))) {
            Thread server = new Thread(() -> {
                try {
                    mock.setSoTimeout(3500);
                    byte[] buf = new byte[2048];
                    DatagramPacket rx = new DatagramPacket(buf, buf.length);
                    mock.receive(rx);
                    byte[] request = rx.getData();
                    if (rx.getLength() != 11 || request[0] != (byte)0xfe || request[1] != (byte)0xfd) {
                        throw new AssertionError("Wrong GameSpy header");
                    }
                    byte[] token = Arrays.copyOfRange(request, 3, 7);
                    byte[] badToken = token.clone();
                    badToken[0] ^= 0x22;
                    byte[] wrong = reply(badToken);
                    mock.send(new DatagramPacket(wrong, wrong.length, rx.getAddress(), rx.getPort()));
                    byte[] good = reply(token);
                    mock.send(new DatagramPacket(good, good.length, rx.getAddress(), rx.getPort()));
                    mock.send(new DatagramPacket(good, good.length, rx.getAddress(), rx.getPort()));
                } catch (Throwable ex) { serverError.set(ex); }
            }, "bf2-lan-mock");
            server.start();
            List<LanQuery.Result> servers = LanDiscovery.scanTargets(
                    Arrays.asList(InetAddress.getByName("127.0.0.1")), mock.getLocalPort(), 650);
            server.join(1500);
            if (serverError.get() != null) throw new AssertionError(serverError.get());
            check(servers.size() == 1, "broadcast search deduplicates and ignores bad token");
            check(servers.get(0).hostname.equals("LAN Server"), "discovery parses server name");
            check(servers.get(0).gamePort == 16567, "discovery parses game port");
            check(servers.get(0).map.equals("Strike_at_Karkand"), "discovery parses map name");
            check(servers.get(0).queryPort == mock.getLocalPort(), "query and game ports remain distinct");
        }
    }

    public static void main(String[] args) throws Exception {
        testLaunch();
        testDiscoveryFixture();
        check(LanDiscovery.scanTargets(java.util.Collections.emptyList(), 29900, 300).isEmpty(), "empty targets return empty list");
        System.out.println("ALL " + count + " TESTS PASSED");
    }
}
