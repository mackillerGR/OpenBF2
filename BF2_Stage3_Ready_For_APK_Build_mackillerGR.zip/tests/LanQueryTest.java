import com.mackillergr.bf2.lan.LanQuery;
import com.mackillergr.bf2.lan.LanJoinArgs;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

public class LanQueryTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        byte[] token = new byte[]{1,2,3,4};
        byte[] req = LanQuery.request(token);
        check(req.length == 11 && (req[0] & 255) == 254 && (req[7] & 255) == 255, "Request wire bytes");
        byte[] payload = "splitnum\0".getBytes(StandardCharsets.US_ASCII);
        byte[] fields = ("\0hostname\0BF2 Java LAN\0hostport\0" + "16567\0mapname\0Karkand\0\0").getBytes(StandardCharsets.ISO_8859_1);
        byte[] response = new byte[5 + payload.length + 1 + fields.length];
        System.arraycopy(new byte[]{0,1,2,3,4},0,response,0,5);
        System.arraycopy(payload,0,response,5,payload.length);
        response[5 + payload.length] = (byte) 0x80;
        System.arraycopy(fields,0,response,6+payload.length, fields.length);
        Map<String,String> map = LanQuery.parseResponse(response, response.length, token);
        check("BF2 Java LAN".equals(map.get("hostname")), "Parse GameSpy response");
        check("16567".equals(map.get("hostport")), "Parse game port");
        check(LanQuery.safePort("bad", 16567) == 16567, "Bad port fallback");
        check(LanJoinArgs.isIPv4("192.168.1.23") && !LanJoinArgs.isIPv4("999.1.2.3"), "IPv4 validation");
        check(Arrays.equals(LanJoinArgs.directIp(new String[]{"--mod","/game","--menu"}, "192.168.1.23",16567), new String[]{"--mod","/game","--connect","192.168.1.23:16567"}), "Join args");
        // Host loopback fixture: Java client query must match the wire protocol.
        try (DatagramSocket server = new DatagramSocket(0, InetAddress.getByName("127.0.0.1"))) {
            final Throwable[] threadError = new Throwable[1];
            Thread thread = new Thread(() -> {
                try {
                    byte[] in = new byte[200];
                    DatagramPacket packet = new DatagramPacket(in, in.length);
                    server.receive(packet);
                    byte[] t = Arrays.copyOfRange(in,3,7);
                    byte[] msg = "splitnum\0".getBytes(StandardCharsets.US_ASCII);
                    byte[] f = ("\0hostname\0Test BF2 Server\0hostport\0" + "16567\0\0").getBytes(StandardCharsets.ISO_8859_1);
                    byte[] out = new byte[5 + msg.length + 1 + f.length];
                    out[0] = 0;
                    System.arraycopy(t,0,out,1,4);
                    System.arraycopy(msg,0,out,5,msg.length);
                    out[5+msg.length] = (byte) 0x80;
                    System.arraycopy(f,0,out,6+msg.length,f.length);
                    server.send(new DatagramPacket(out,out.length,packet.getAddress(),packet.getPort()));
                } catch (Throwable e) { threadError[0] = e; }
            });
            thread.start();
            LanQuery.Result reply = LanQuery.query("127.0.0.1",server.getLocalPort(),1000);
            thread.join(1000);
            check(threadError[0] == null, "Local fixture error");
            check("Test BF2 Server".equals(reply.hostname), "UDP request-response");
            check(reply.gamePort == 16567, "Gameport read");
        }
        System.out.println("PASS: Java query, parsing, validation, CLI arguments, UDP loopback fixture");
    }
}
