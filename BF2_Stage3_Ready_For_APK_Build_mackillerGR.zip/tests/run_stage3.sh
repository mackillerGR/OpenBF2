#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
bash "$ROOT/tests/run_all.sh"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
javac -encoding UTF-8 -d "$BUILD" \
  "$ROOT/app/src/main/java/com/mackillergr/bf2/lan/LanJoinArgs.java" \
  "$ROOT/gameapp/src/main/java/com/mackillergr/bf2/GameLaunchPlan.java" \
  "$ROOT/tests/GameLaunchPlanTest.java"
java -cp "$BUILD" GameLaunchPlanTest
javac -encoding UTF-8 -d "$BUILD" "$ROOT/tests/ParseAndroidSources.java"
java -cp "$BUILD" ParseAndroidSources \
  "$ROOT/gameapp/src/main/java/com/mackillergr/bf2/LauncherActivity.java" \
  "$ROOT/gameapp/src/main/java/com/mackillergr/bf2/GameActivity.java" \
  "$ROOT/gameapp/src/main/java/com/mackillergr/bf2/LanBrowserActivity.java"
PYTHONPATH="$ROOT" python -m unittest discover -s "$ROOT/tests" -p 'test_stage3_package.py' -v
