import com.mackillergr.bf2.GameLaunchPlan;
import java.util.Arrays;
import java.util.List;

public class GameLaunchPlanTest {
    private static int passed;
    private static void check(boolean ok, String why) {
        if (!ok) throw new AssertionError(why);
        passed++;
        System.out.println("PASS " + why);
    }
    private static String valueAfter(List<String> args, String flag) {
        int p = args.indexOf(flag);
        return p < 0 || p+1 >= args.size() ? null : args.get(p+1);
    }
    private static void rejects(Runnable run, String why) {
        boolean rejected = false;
        try { run.run(); } catch (IllegalArgumentException ex) { rejected = true; }
        check(rejected, why);
    }
    public static void main(String[] ignored) {
        String mod="/storage/emulated/0/Android/data/com.mackillergr.bf2.stage3/files/Game Files/mods/bf2";
        String lib="/data/app/lib/arm64";
        List<String> menu = Arrays.asList(GameLaunchPlan.forMenu(mod,lib,1280,720,"Player1","system"));
        check(menu.get(menu.size()-1).equals("--menu"), "native menu flag last");
        check(!menu.contains("--level") && !menu.contains("--connect"), "menu does not force a map or server");
        check(mod.equals(valueAfter(menu,"--mod")), "path passed to native");
        check(lib.equals(valueAfter(menu,"--libdir")), "native libdir passed");
        check("system".equals(valueAfter(menu,"--driver")), "renderer choice passed");
        List<String> lan = Arrays.asList(GameLaunchPlan.forLan(mod,lib,1280,720,"Player2","turnip","192.168.1.42",16567));
        check("192.168.1.42:16567".equals(valueAfter(lan,"--connect")), "real LAN ip:gameport passed");
        check(!lan.contains("--menu")&&!lan.contains("--level")&&!lan.contains("--hosted"), "LAN join has no auto-level flags");
        check("turnip".equals(valueAfter(lan,"--driver")), "turnip driver passed");
        rejects(()->GameLaunchPlan.forMenu("relative",lib,1280,720,"P","system"),"reject relative path");
        rejects(()->GameLaunchPlan.forMenu(mod,lib,320,240,"P","system"),"reject bad dimensions");
        rejects(()->GameLaunchPlan.forMenu(mod,lib,1280,720,"","system"),"reject empty player");
        rejects(()->GameLaunchPlan.forMenu(mod,lib,1280,720,"P","unknown"),"reject unknown driver");
        rejects(()->GameLaunchPlan.forLan(mod,lib,1280,720,"P","system","1.2.3.999",16567),"reject bad IPv4");
        rejects(()->GameLaunchPlan.forLan(mod,lib,1280,720,"P","system","192.168.1.42",99999),"reject bad port");
        System.out.println("ALL "+passed+" INTEGRATED LAUNCH PLAN CHECKS PASS");
    }
}
