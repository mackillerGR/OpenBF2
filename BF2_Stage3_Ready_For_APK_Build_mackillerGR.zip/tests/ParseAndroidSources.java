import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import com.sun.source.util.JavacTask;

/** Syntax-only validation of Android Java files, no android.jar required. */
public final class ParseAndroidSources {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager fm = compiler.getStandardFileManager(diagnostics, null, null)) {
            Iterable<? extends JavaFileObject> files = fm.getJavaFileObjectsFromStrings(Arrays.asList(args));
            JavacTask parser = (JavacTask) compiler.getTask(null, fm, diagnostics,
                    Arrays.asList("-proc:none"), null, files);
            parser.parse();
            for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.ERROR) {
                    System.err.println(d);
                    System.exit(1);
                }
            }
        }
        System.out.println("PASS Android sources syntax parsed (SDK unavailable; not compiled)");
    }
}
