# Πώς δημιουργείται το πραγματικό APK του Stage 3

**Σημαντικό:** Στην παρούσα συνεδρία ΔΕΝ έγινε Android APK build. Το περιβάλλον δεν έχει Android SDK, Android build-tools ή Gradle και δεν διαθέτει πρόσβαση για τις επίσημες λήψεις τους. Το πακέτο περιέχει τα αρχεία για να γίνει το build αλλού και **δεν περιέχει εγκαταστάσιμο APK**.

## Επιλογή A — GitHub Actions, χωρίς τοπικό SDK

1. Δημιούργησε προσωρινό *private* repository ή χρησιμοποίησε ξεχωριστό branch. Ανέβασε **όλο το περιεχόμενο** αυτού του φακέλου ως root (όχι μόνο το workflow). Το `gameapp/src/main/jniLibs/arm64-v8a/` περιέχει τα 15 αρχεία `.so` από το δικό σου test13 APK. Μην ανεβάσεις δεδομένα εμπορικού παιχνιδιού ή κλειδιά CD.
2. Άνοιξε **Actions > Build BF2 Android Stage 3 APK > Run workflow**. Μπορεί να απαιτείται να επιτρέψεις το GitHub Actions στο repo.
3. Μετά από επιτυχημένο run, στη σελίδα του workflow, στα **Artifacts**, κατέβασε το `BF2_Android_LAN_Stage3_debug_APK`.
4. Το APK είναι μέσα στο artifact ZIP ως `gameapp-debug.apk`. Εγκατάστησέ το μόνο σε ARM64 Android συσκευή. Το debug APK χρησιμοποιεί διαφορετικό package από το test13 (`com.mackillergr.bf2.stage3`).

Οποιοδήποτε πράσινο GitHub Actions run αποδεικνύει μόνο την επιτυχία build και signature verification, **όχι** ότι το μενού του Battlefield 2 ή το LAN gameplay λειτουργεί.

## Επιλογή B — Τοπικό build (Linux / WSL)

Απαιτούνται JDK 17, Android SDK platform 35 + build tools 35, Gradle 8.9+, Python 3 και πρόσβαση στο internet για το επίσημο SDL3 3.4.14 Java glue.

```bash
bash BUILD_APK.sh
```

Παραγόμενο αρχείο: `gameapp/build/outputs/apk/debug/gameapp-debug.apk`.

## Πραγματική κατάσταση

- Έχουμε 15 ARM64 `.so` από το `test13.apk`.
- Το υπάρχον native `libmain.so` παραμένει το test13 binary· δεν αποδεικνύεται ότι έχει πλήρες μενού ή LAN handshake.
- Το GitHub repository `mackillerGR/OpenBF2` διαθέτει **branch `android-port`** με το αρχικό `android/src` και `android/build_apk.sh`, παρότι το default branch `main` δεν έχει αυτά τα αρχεία. Δεν χρειάζεται να ανακτηθούν όλα από το DEX.
- Το παραπάνω workflow και το Stage3 build πρέπει να εκτελεστούν σε πραγματικό Android SDK περιβάλλον· δεν έχουν εκτελεστεί σε αυτή τη συνεδρία.
