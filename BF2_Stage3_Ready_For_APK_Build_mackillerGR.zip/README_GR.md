# Battlefield 2 Android by mackillerGR — Stage 3 / Integrated LAN Launcher

**Ημερομηνία:** 6 Νοεμβρίου 2026

## Τι άλλαξε από το Stage 2

Το Stage 2 ήταν **ξεχωριστό** Android LAN diagnostic companion και δεν μπορούσε να
ξεκινήσει εσωτερικά το μη-exported `GameActivity` του test13. Το **Stage 3** περιλαμβάνει
νέο `:gameapp` module, με κλάσεις `com.mackillergr.bf2.LauncherActivity`,
`GameActivity` και `LanBrowserActivity` στο **ίδιο Android application process/package**.
Αυτό σημαίνει ότι μπορεί να καλέσει **δικό του** `GameActivity` με πραγματικό `Intent
args` αντί να ανοίγει απλώς το `test13`. Δεν έχει ακόμη αποδειχθεί ότι το native
BF2 client φορτώνει το μενού ή ολοκληρώνει LAN game session.

Συγκεκριμένα υλοποιήθηκαν:

- Νέος ενσωματωμένος launcher με επιλογές **Αυθεντικό μενού (`--menu`)** και **LAN Direct Connect (`--connect IP:16567`)**.
- Ενσωματωμένος `LanBrowserActivity` με broadcast και direct-IP GameSpy UDP query (29900)
  και επιστροφή της επιλεγμένης διεύθυνσης στο launcher.
- Έλεγχος του `ClientArchives.con`, και των έξι archives, και ύπαρξης `libmain.so`.
- `GameLaunchPlan` με απομόνωση `--menu` από `--level`/`--connect` και με CLI flags
  `--mod`, `--width`, `--height`, `--name`, `--libdir`, `--driver`.
- `GameActivity` που επαναφέρει την **ακριβή σειρά JNI βιβλιοθηκών που ανακτήθηκε** από το
  `test13` DEX: `c++_shared`, `SDL3`, `dice_py`, `dxvk_d3d9`, `vkd3d-shader`, `main`.
- Εξαγωγή και ενσωμάτωση 15 *δικών σου* ARM64 `.so` από το test13 (διατηρούνται αυτούσιες).
- Πηγαία Java SDL3 από το επίσημο **release-3.4.14**, ίδια έκδοση με τη native
  `libSDL3.so` (`SDL-3.4.14-HEAD-HASH-NOTFOUND`), μέσω επαληθευμένου download script.
- Δεύτερο module `:app` που διατηρεί το λειτουργικό Stage 2 diagnostic companion.

## Πώς γίνεται Android build σε PC

Χρειάζεσαι **Android Studio, Android SDK 35, JDK 17, Gradle 8.9+** και internet
για λήψη των Android Gradle Plugin και upstream SDL Java πηγών.
**Δεν περιλαμβάνεται Gradle wrapper**, οπότε χρησιμοποίησε Gradle που διαθέτει το
Android Studio ή εγκατάστησε Gradle στην ανάπτυξη. Το build APK δεν εκτελέστηκε
στο παρόν περιβάλλον, επειδή δεν διαθέτει Android SDK/Gradle.

1. Αποσυμπίεσε αυτό το ZIP στο PC.
2. Από τον φάκελο Stage 3 εκτέλεσε:

   ```bash
   python scripts/fetch_sdl_java.py
   ```

   Το script κατεβάζει 12 επίσημα αρχεία Java SDL 3.4.14. Για καθένα ελέγχει
   Git blob SHA-1 που διαβάστηκε από το επίσημο tag (όχι αόριστη έκδοση `main`).
   Οι πηγές SDL ανήκουν στο SDL project, με άδεια zlib.
3. Άνοιξε τον φάκελο `BF2_Android_LAN_Stage3` στο Android Studio.
   Κάνε Gradle Sync, επίλεξε `:gameapp` και κάνε `assembleDebug`.
4. Εγκατάστησε το dev APK `com.mackillergr.bf2.stage3` στο ARM64 Android σου.
   **Δεν αντικαθιστά** το παλιό `com.mackillergr.bf2` (test13), άρα δεν υπάρχει
   πρόβλημα ασύμβατης υπογραφής / ακούσιας απώλειας δεδομένων.
5. Βάλε *τα δικά σου* δεδομένα BF2 στο app-specific directory που εμφανίζει το
   πεδίο `Φάκελος mods/bf2` (ή άλλαξε το path σε προσβάσιμο πραγματικό φάκελο):

   ```text
   /storage/emulated/0/Android/data/com.mackillergr.bf2.stage3/files/Game Files/mods/bf2/
     ClientArchives.con
     Objects_client.zip
     Common_client.zip
     Menu_client.zip
     Fonts_client.zip
     Shaders_client.zip
     Booster_client.zip
     Levels/Strike_at_Karkand/client.zip
     Levels/Strike_at_Karkand/server.zip
     ...
   ```

   Για Android 11+ συνιστάται εισαγωγή με ADB ή ροή που επιτρέπει νόμιμη πρόσβαση
   στο app-specific directory. Η εφαρμογή **δεν** περιέχει μηχανισμό SAF import,
   ούτε προσποιείται ότι έχει πρόσβαση σε οποιονδήποτε επιλεγμένο φάκελο.
6. Στο νέο launcher πάτα **Έλεγχος αρχείων**, έπειτα **Έναρξη στο μενού** ή
   **Αναζήτηση LAN servers → Επιλογή → Σύνδεση**. Το query μπορεί να δουλεύει
   ανεξάρτητα από την κατάσταση της μηχανής BF2.

### Αν δεν έχεις ακόμη τις `.so`

Το Stage 3 ZIP περιλαμβάνει τις 15 ARM64 native βιβλιοθήκες που εξήχθησαν από
το test13 που ανέβασες. Το script μπορεί να τις αναδημιουργήσει από το αρχικό
APK χωρίς αλλαγές:

```bash
python scripts/prepare_stage3.py Battlefield2_by_mackillerGR_test13.apk
```

**Δεν** παρέχονται τα εμπορικά BF2 game data μέσα στο πακέτο. Για να τα
προετοιμάσεις από τα δικά σου uploads, χρησιμοποίησε το
`scripts/bf2_android_assets.py` (από το Recovery Kit, περιλαμβάνεται εδώ).

## Τεχνικά εμπόδια που δεν έχουν κλείσει

1. Το νέο Android module είναι **ανακατασκευή launcher**, όχι recompilation του
   `libmain.so`: η μεταγλωττισμένη native engine παραμένει ίδια με το `test13`.
2. Το αυθεντικό SWF μενού στο OpenBF2 έχει γνωστά `[FRONTIER]` σημεία, όπως
   `swiffFsCommand`. Δεν παρακάμφθηκαν ούτε τροποποιήθηκαν αυθαίρετα.
3. Δεν έχει γίνει αποδεδειγμένο BF2 UDP game handshake, map join, spawn ή
   cross-platform gameplay. LAN server query != σύνδεση στο παιχνίδι.
4. Ο παλιός `TouchOverlay` δεν έχει ανακατασκευαστεί πλήρως. Το νέο module βασίζεται
   προσωρινά στα input events του SDL3 (keyboard/mouse/controller).
5. Δεν περιλαμβάνεται native Android C++ rebuild target του OpenBF2· στο
   δημόσιο repository υπάρχουν builds Windows / Linux. Το binary test13 δεν
   αποδεικνύει ότι οι υποκείμενες λειτουργίες του client ολοκληρώθηκαν.
6. Για επιβεβαίωση χρειάζεται **Android SDK build και δοκιμή σε φυσική συσκευή**
   (προτιμότερα ίδια με εκείνη που έτρεχε το test13) και logcat:

   ```bash
   adb logcat -c
   # Άνοιξε το Stage3 gameapp και διάλεξε --menu ή --connect.
   adb logcat -d -v threadtime > bf2_stage3_logcat.txt
   ```

   Μη δημοσιεύεις προσωπικές διευθύνσεις, private keys ή CD keys σε δημόσια logs.

## Offline δοκιμές που εκτελέστηκαν

```bash
bash tests/run_stage3.sh
```

Περιλαμβάνουν mock UDP GameSpy server, parsing, ασφάλεια IP/ports, UI source
syntax parser χωρίς Android SDK, Java launcher args, XML manifest και
επικύρωση της σειράς JNI βιβλιοθηκών / version string από το πραγματικό APK.
Διάβασε `stage3_test_results.log` για ακριβή αποτελέσματα.

## Πηγές και περιορισμοί χρήσης

- https://github.com/mackillerGR/OpenBF2 — δημόσιο `main`, engine in progress.
- https://github.com/libsdl-org/SDL/tree/release-3.4.14/android-project/app/src/main/java/org/libsdl/app
- Τροποποιήσεις στο upstream OpenBF2 δεν έγιναν. Δεν δημιουργήθηκε PR.
- Κώδικας Android Stage3 είναι νέα εργασία, δεν ισχυρίζεται πιστή
  ανακατασκευή ιδιοταγούς Battlefield 2 native source από μη επαληθευμένα στοιχεία.
