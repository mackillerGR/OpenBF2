#!/usr/bin/env python3
"""Extract native libraries from the user's original APK for an eventual full rebuild.
No DEX conversion or engine recompilation is claimed. Does not modify original APK.
"""
import argparse
import hashlib
from pathlib import Path
from zipfile import ZipFile

p = argparse.ArgumentParser()
p.add_argument('apk', help='The original Battlefield2_by_mackillerGR_test13.apk')
p.add_argument('--output', default='extracted_test13_native', help='Directory for extracted *.so')
a = p.parse_args()
dest = Path(a.output).resolve()
entries = []
with ZipFile(a.apk) as archive:
    for entry in archive.infolist():
        if not entry.filename.startswith('lib/arm64-v8a/') or not entry.filename.endswith('.so'):
            continue
        target = dest / Path(entry.filename).name
        dest.mkdir(parents=True, exist_ok=True)
        data = archive.read(entry)
        target.write_bytes(data)
        entries.append((target.name, len(data), hashlib.sha256(data).hexdigest()))
for file, size, sha in entries:
    print(f'{file:35} {size:>10} bytes sha256={sha}')
print(f'EXTRACTED {len(entries)} arm64 libraries -> {dest}')
