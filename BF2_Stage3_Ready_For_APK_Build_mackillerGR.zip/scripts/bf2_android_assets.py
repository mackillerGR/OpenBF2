#!/usr/bin/env python3
"""Validate BF2 retail data and optionally stage it for a user-owned Android port.

Works with Objects_client.zip.001/002/... split by raw byte size (not multipart ZIP format).
Does not patch engine, provide a compiled APK, or bypass DRM.
"""
import argparse
import io
import pathlib
import shutil
import sys
import tempfile
import zipfile

ARCHIVES = [
    'Objects_client.zip', 'Common_client.zip', 'Menu_client.zip',
    'Fonts_client.zip', 'Shaders_client.zip', 'Booster_client.zip'
]
MAP = 'Strike_at_Karkand'

def pieces_for(source):
    single=source/'Objects_client.zip'
    if single.is_file():return [single]
    parts=sorted(source.glob('Objects_client.zip.[0-9][0-9][0-9]'))
    if not parts:raise FileNotFoundError('Missing Objects_client.zip or numbered pieces')
    for i,p in enumerate(parts,1):
        if p.name!=f'Objects_client.zip.{i:03d}':raise ValueError('Missing part of Objects_client.zip before '+p.name)
    return parts

def copy_concat(parts,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('wb') as dst:
        for part in parts:
            with part.open('rb') as src:shutil.copyfileobj(src,dst,4*1024*1024)

def check_zip(path, crc=False):
    with zipfile.ZipFile(path) as z:
        count=len(z.infolist());uncompressed=sum(i.file_size for i in z.infolist())
        if crc:
            bad=z.testzip()
            if bad:raise ValueError(f'CRC error in {path}: {bad}')
        return count,uncompressed

def sanitized_extract_members(z, prefix, output):
    prefix=prefix.rstrip('/')+'/'
    for member in z.infolist():
        name=member.filename.replace('\\','/')
        if not name.startswith(prefix):continue
        rel=pathlib.PurePosixPath(name.removeprefix(prefix))
        if not str(rel) or str(rel)=='.':continue
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe ZIP path: '+name)
        dst=output.joinpath(*rel.parts)
        if member.is_dir():dst.mkdir(parents=True,exist_ok=True)
        else:
            dst.parent.mkdir(parents=True,exist_ok=True)
            with z.open(member) as src,dst.open('wb') as out:shutil.copyfileobj(src,out,4*1024*1024)

def main():
    parser=argparse.ArgumentParser(description='Validate and stage Battlefield 2 client archives and Strike at Karkand')
    parser.add_argument('--source',required=True,help='Directory containing uploaded BF2 archive files')
    parser.add_argument('--output',help='Destination mods/bf2 directory. If omitted, only validates.')
    parser.add_argument('--full-crc',action='store_true',help='Read all archive data to CRC-check (slower)')
    args=parser.parse_args()
    source=pathlib.Path(args.source).resolve();dest=pathlib.Path(args.output).resolve() if args.output else None
    if not source.is_dir():parser.error('Source is not a directory: '+str(source))
    if dest is not None and (dest==source or source in dest.parents):parser.error('Choose an output outside the input directory')
    con=next((p for p in [source/'ClientArchives.con',source/'ClientArchives(1).con'] if p.is_file()),None)
    if not con:raise FileNotFoundError('ClientArchives.con not found')
    config=con.read_text(errors='replace')
    for name in ARCHIVES:
        if name not in config:print('WARN ClientArchives.con does not mention',name)
    print('ClientArchives.con:',con.name)
    for name in ARCHIVES:
        if name=='Objects_client.zip':
            parts=pieces_for(source)
            if len(parts)>1:
                # ZIP central directory sits in last part. Assemble temporarily for structural validation.
                with tempfile.TemporaryDirectory(prefix='bf2-objects-check-') as td:
                    full=pathlib.Path(td)/name
                    print('Joining',len(parts),'parts temporarily to inspect',name,flush=True)
                    copy_concat(parts,full)
                    count,size=check_zip(full,args.full_crc)
                    if dest:copy_concat(parts,dest/name)
            else:
                count,size=check_zip(parts[0],args.full_crc)
                if dest:
                    (dest/name).parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(parts[0],dest/name)
        else:
            src=source/name
            if not src.is_file():raise FileNotFoundError(src)
            count,size=check_zip(src,args.full_crc)
            if dest:
                (dest/name).parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(src,dest/name)
        print(f'OK {name}: {count:,} entries; {size:,} bytes uncompressed')
    src=source/f'{MAP}.zip'
    if not src.is_file():raise FileNotFoundError(src)
    with zipfile.ZipFile(src) as outer:
        names=outer.namelist()
        for item in (f'{MAP}/client.zip',f'{MAP}/server.zip',f'{MAP}/Info/{MAP}.desc'):
            if item not in names:raise ValueError('Missing map resource '+item)
        for item in (f'{MAP}/client.zip',f'{MAP}/server.zip'):
            with outer.open(item) as stream:
                # Nested ZIP is modest (~36 MB); inspect without unpacking map assets.
                data=stream.read()
                with zipfile.ZipFile(io.BytesIO(data)) as inner:
                    if args.full_crc and inner.testzip() is not None:raise ValueError('Bad map ZIP: '+item)
                    print('OK',item,'entries:',len(inner.namelist()))
        if dest:sanitized_extract_members(outer,f'{MAP}/',dest/'Levels'/MAP)
    if dest:
        shutil.copy2(con,dest/'ClientArchives.con')
        print('Staged content in:',dest)
        print('This only prepares files. It does NOT establish that the Android engine loads them.')
    else:print('Check only: nothing was copied or modified.')

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,zipfile.BadZipFile) as ex:print('ERROR:',ex,file=sys.stderr);sys.exit(1)
