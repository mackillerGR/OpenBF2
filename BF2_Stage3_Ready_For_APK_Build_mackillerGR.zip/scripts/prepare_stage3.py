#!/usr/bin/env python3
"""Prepare test13's native libraries for the reconstructed integrated gameapp.
Does NOT build an APK, decompile the engine or add retail game assets.
"""
import argparse
import hashlib
from pathlib import Path
from zipfile import ZipFile

NAMES = (
 "libc++_shared.so", "libSDL3.so", "libmain.so", "libdice_py.so", "libRendDX9.so",
 "libBF2Audio.so", "libSwiffPlayer.so", "libopenal.so", "libdxvk_d3d9.so",
 "libvkd3d-shader.so", "libvulkan_freedreno.so", "libgsl_alloc_hook.so",
 "libhook_impl.so", "libmain_hook.so", "libfile_redirect_hook.so"
)

def prepare(apk: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    with ZipFile(apk) as archive:
        actual = {p.filename for p in archive.infolist() if p.filename.startswith('lib/arm64-v8a/') and p.filename.endswith('.so')}
        wanted = {'lib/arm64-v8a/' + name for name in NAMES}
        if not wanted.issubset(actual):
            raise RuntimeError(f"Missing libraries: {sorted(wanted - actual)}")
        for name in NAMES:
            data = archive.read('lib/arm64-v8a/' + name)
            out = dest / name
            out.write_bytes(data)
            print(f"COPY {name:33} {len(data):>10} bytes  sha256={hashlib.sha256(data).hexdigest()[:12]}…")
    print(f"Prepared {len(NAMES)} ARM64 libs in {dest}")

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('apk', type=Path, help='Your original test13 APK')
    p.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'gameapp/src/main/jniLibs/arm64-v8a')
    args=p.parse_args()
    prepare(args.apk,args.output)
