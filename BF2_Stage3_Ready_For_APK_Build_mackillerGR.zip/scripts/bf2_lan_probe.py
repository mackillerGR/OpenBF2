#!/usr/bin/env python3
"""Battlefield 2 GameSpy query-port probe for servers on your own LAN.

This does NOT implement gameplay / join / account authentication. Protocol 00,
subprotocol A: FE FD 00 + request-id (4 B) + header/player/team flags + 00.
"""
from __future__ import annotations

import argparse
import json
import secrets
import socket
import sys
import time
from dataclasses import asdict, dataclass
from typing import Optional

MAX_REPLY = 4096
DEFAULT_QUERY_PORT = 29900
DEFAULT_GAME_PORT = 16567


@dataclass
class ServerInfo:
    address: str
    query_port: int
    game_port: int
    hostname: str
    game: str
    version: str
    map_name: str
    players: str
    max_players: str
    punkbuster: str
    raw: dict[str, str]


def make_request(token: bytes) -> bytes:
    if len(token) != 4:
        raise ValueError("The query token must have 4 bytes")
    # GameSpy protocol 00; only ask for server headers (FF 00 00 00).
    return b"\xfe\xfd\x00" + token + b"\xff\x00\x00\x00"


def parse_response(data: bytes, token: bytes) -> dict[str, str]:
    """Parse a single GameSpy reply (headers only); reject unrelated datagrams.

    Reply may be 00 + token + 'splitnum\\0' + split index + section marker,
    or a legacy 00 + token + header list. This is NOT a full split/reassembly parser.
    """
    if len(token) != 4:
        raise ValueError("Invalid token")
    if len(data) < 6 or data[0:1] != b"\x00" or data[1:5] != token:
        raise ValueError("Not the response to our GameSpy query")
    tail = data[5:]
    if tail.startswith(b"splitnum\x00"):
        if len(tail) < 10:
            raise ValueError("Truncated split response")
        # An 8-bit index follows 'splitnum\0'; last-packet marker may be high bit.
        tail = tail[10:]
    # Headers may begin with a section marker 00 before the first ASCII key.
    tail = tail.lstrip(b"\x00")
    fields = tail.split(b"\x00")
    result: dict[str, str] = {}
    for i in range(0, len(fields) - 1, 2):
        key = fields[i].decode("latin-1", errors="replace").strip().lower()
        value = fields[i + 1].decode("latin-1", errors="replace").strip()
        if key and len(key) <= 90 and all(32 <= ord(ch) <= 126 for ch in key):
            result[key] = value
    if not result:
        raise ValueError("Reply contained no recognizable server headers")
    return result


def summarize(address: str, query_port: int, fields: dict[str, str]) -> ServerInfo:
    value = fields.get("hostport", str(DEFAULT_GAME_PORT))
    try:
        game_port = int(value)
        if not 1 <= game_port <= 65535:
            raise ValueError("out of range")
    except ValueError:
        game_port = DEFAULT_GAME_PORT
    return ServerInfo(
        address=address, query_port=query_port, game_port=game_port,
        hostname=fields.get("hostname", "(χωρίς όνομα)"),
        game=fields.get("gamename", ""), version=fields.get("gamever", ""),
        map_name=fields.get("mapname", ""), players=fields.get("numplayers", "?"),
        max_players=fields.get("maxplayers", "?"),
        punkbuster=fields.get("bf2_anticheat", "unknown"), raw=fields,
    )


def query_servers(host: str, query_port: int = DEFAULT_QUERY_PORT, timeout: float = 1.7,
                  broadcast: bool = False) -> list[ServerInfo]:
    if not (1 <= query_port <= 65535):
        raise ValueError("query port out of range")
    if timeout <= 0 or timeout > 30:
        raise ValueError("timeout must be >0 and <=30 seconds")
    token = secrets.token_bytes(4)
    packet = make_request(token)
    endpoint = ("255.255.255.255" if broadcast else host, query_port)
    deadline = time.monotonic() + timeout
    results: dict[tuple[str, int], ServerInfo] = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, int(broadcast))
        sock.bind(("0.0.0.0", 0))
        sock.sendto(packet, endpoint)
        while time.monotonic() < deadline:
            sock.settimeout(max(0.001, deadline - time.monotonic()))
            try:
                data, src = sock.recvfrom(MAX_REPLY)
            except socket.timeout:
                break
            if src[1] != query_port:
                continue
            if not broadcast and src[0] != socket.gethostbyname(host):
                continue
            try:
                fields = parse_response(data, token)
            except ValueError:
                continue
            results[src] = summarize(src[0], query_port, fields)
            if not broadcast:
                break
    return list(results.values())


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="BF2 LAN diagnostic query (NO gameplay connection)")
    p.add_argument("host", nargs="?", help="Server local IP (e.g. 192.168.1.50)")
    p.add_argument("--query-port", type=int, default=DEFAULT_QUERY_PORT)
    p.add_argument("--timeout", type=float, default=1.7)
    p.add_argument("--broadcast", action="store_true", help="Ask LAN broadcast for local servers")
    p.add_argument("--json", action="store_true", help="Machine-readable output")
    args = p.parse_args(argv)
    if not args.host and not args.broadcast:
        p.error("Provide an IP address or use --broadcast")
    try:
        found = query_servers(args.host or "", args.query_port, args.timeout, args.broadcast)
    except (OSError, ValueError) as e:
        print(f"Σφάλμα δικτύου: {e}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps([asdict(x) for x in found], ensure_ascii=False, indent=2))
    elif found:
        for s in found:
            print(f"[SERVER] {s.hostname}\n  IP: {s.address}:{s.game_port} "
                  f"(query UDP {s.query_port})\n  Map: {s.map_name} "
                  f"| Players: {s.players}/{s.max_players} | Version: {s.version}\n"
                  f"  Anti-cheat: {s.punkbuster}\n")
        print("Ο server απάντησε σε GameSpy query. Αυτό ΔΕΝ επιβεβαιώνει είσοδο στο παιχνίδι.")
    else:
        print("Καμία απάντηση στο query. Πιθανά: λάθος IP, firewall, λάθος θύρα, "
              "query service ανενεργό ή broadcast αποκλεισμένο.")
    return 0 if found else 1


if __name__ == "__main__":
    raise SystemExit(main())
