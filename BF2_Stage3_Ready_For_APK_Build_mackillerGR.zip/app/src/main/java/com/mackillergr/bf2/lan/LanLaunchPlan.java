package com.mackillergr.bf2.lan;

import java.util.ArrayList;
import java.util.List;

/** Validated, immutable plan for a FUTURE integrated SDL3 GameActivity launcher. */
public final class LanLaunchPlan {
    public enum Mode { MENU, DIRECT_LAN }
    public final String[] arguments;
    public final Mode mode;

    private LanLaunchPlan(Mode mode, String[] arguments) {
        this.mode = mode;
        this.arguments = arguments.clone();
    }

    public static LanLaunchPlan menu(String modPath, int width, int height, String player) {
        List<String> args = common(modPath, width, height, player);
        args.add("--menu");
        return new LanLaunchPlan(Mode.MENU, args.toArray(new String[0]));
    }

    public static LanLaunchPlan directLan(String modPath, int width, int height,
                                          String player, String serverIP, int gamePort) {
        List<String> args = common(modPath, width, height, player);
        String[] joined = LanJoinArgs.directIp(args.toArray(new String[0]), serverIP, gamePort);
        return new LanLaunchPlan(Mode.DIRECT_LAN, joined);
    }

    private static List<String> common(String modPath, int width, int height, String player) {
        if (modPath == null || !modPath.startsWith("/") || modPath.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Valid absolute BF2 mod directory required");
        if (width < 640 || height < 480 || width > 7680 || height > 4320)
            throw new IllegalArgumentException("Invalid display dimensions");
        if (player == null || player.isEmpty() || player.length() > 32 || player.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Invalid player name");
        List<String> args = new ArrayList<>();
        args.add("--mod"); args.add(modPath);
        args.add("--width"); args.add(Integer.toString(width));
        args.add("--height"); args.add(Integer.toString(height));
        args.add("--name"); args.add(player);
        return args;
    }
}
