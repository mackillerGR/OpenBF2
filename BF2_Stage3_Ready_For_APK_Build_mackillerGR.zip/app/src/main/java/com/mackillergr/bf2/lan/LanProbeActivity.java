package com.mackillergr.bf2.lan;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Standalone LAN diagnostic companion for test13. Does not join/modify BF2 game process. */
public final class LanProbeActivity extends Activity {
    private final ExecutorService networkWorker = Executors.newSingleThreadExecutor();
    private EditText address;
    private EditText queryPort;
    private TextView status;
    private LinearLayout servers;
    private Button scan;
    private Button direct;
    private LanQuery.Result selected;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(19, 25, 36));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        addText(root, "Battlefield 2 — LAN Preflight", 22);
        addText(root, "Ανεξάρτητο εργαλείο εντοπισμού PC BF2 1.50 server. ΔΕΝ είναι ολοκληρωμένο Android multiplayer.", 14);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(Color.LTGRAY);
        address.setHint("IP του PC, π.χ. 192.168.1.100");
        address.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(address);
        queryPort = new EditText(this);
        queryPort.setText("29900");
        queryPort.setSingleLine(true);
        queryPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        queryPort.setTextColor(Color.WHITE);
        root.addView(queryPort);

        scan = new Button(this);
        scan.setText("Αναζήτηση στο τοπικό LAN");
        root.addView(scan);
        scan.setOnClickListener(v -> execute(true));

        direct = new Button(this);
        direct.setText("Έλεγχος της συγκεκριμένης IP");
        root.addView(direct);
        direct.setOnClickListener(v -> execute(false));

        status = addText(root, "Προεπιλογή: UDP query 29900. Εναλλακτικά δώσε IP και πάτησε Έλεγχος.", 14);
        servers = new LinearLayout(this);
        servers.setOrientation(LinearLayout.VERTICAL);
        root.addView(servers);

        Button copy = new Button(this);
        copy.setText("Αντιγραφή IP:gameport");
        root.addView(copy);
        copy.setOnClickListener(v -> {
            if (selected == null) {
                status.setText("Επίλεξε πρώτα server που απάντησε.");
                return;
            }
            String value = selected.ip + ":" + selected.gamePort;
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("BF2 LAN", value));
            status.setText("Αντιγράφηκε " + value + ". Βάλε το στο πεδίο «Διακομιστής» του test13.");
        });

        Button game = new Button(this);
        game.setText("Άνοιγμα Battlefield 2 test13");
        root.addView(game);
        game.setOnClickListener(v -> {
            Intent launch = new Intent();
            launch.setClassName("com.mackillergr.bf2", "com.mackillergr.bf2.LauncherActivity");
            try { startActivity(launch); }
            catch (ActivityNotFoundException | SecurityException ex) {
                status.setText("Δεν εντοπίστηκε εγκατεστημένος launcher test13. " + ex.getClass().getSimpleName());
            }
        });
        setContentView(scroll);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    private TextView addText(LinearLayout container, String text, int sp) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(sp);
        label.setTextColor(Color.WHITE);
        label.setPadding(0, dp(5), 0, dp(5));
        container.addView(label);
        return label;
    }

    private void busy(boolean value) {
        scan.setEnabled(!value);
        direct.setEnabled(!value);
    }

    private int validatedPort() {
        int port;
        try { port = Integer.parseInt(queryPort.getText().toString().trim()); }
        catch (NumberFormatException e) { return -1; }
        return port >= 1 && port <= 65535 ? port : -1;
    }

    private void execute(boolean broadcast) {
        final int port = validatedPort();
        if (port < 0) { status.setText("Μη έγκυρη θύρα query."); return; }
        final String ip = address.getText().toString().trim();
        if (!broadcast && !LanJoinArgs.isIPv4(ip)) {
            status.setText("Δώσε την τοπική IPv4 διεύθυνση του PC."); return;
        }
        selected = null;
        servers.removeAllViews();
        busy(true);
        status.setText(broadcast ? "Ελέγχω τα τοπικά broadcast δίκτυα…" : "Ερώτημα στο " + ip + ":" + port + "…");
        networkWorker.execute(() -> {
            try {
                final List<LanQuery.Result> results;
                if (broadcast) results = LanDiscovery.scan(port, 2000);
                else results = java.util.Collections.singletonList(LanQuery.query(ip, port, 2000));
                runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    busy(false);
                    status.setText("Απάντησαν " + results.size() + " server(s). Query ≠ gameplay handshake.");
                    for (LanQuery.Result info : results) {
                        Button server = new Button(this);
                        server.setAllCaps(false);
                        server.setText(info.hostname + "  (" + info.ip + ":" + info.gamePort + ")\n" +
                                info.map + " · " + info.players + "/" + info.maxPlayers +
                                " παίκτες · v" + info.version);
                        servers.addView(server);
                        server.setOnClickListener(v -> {
                            selected = info;
                            address.setText(info.ip);
                            status.setText("Επιλέχθηκε: " + info.hostname + ".\nGame: " +
                                    info.ip + ":" + info.gamePort + "\nQuery: UDP " + info.queryPort +
                                    "\nΔεν έχει γίνει σύνδεση στο παιχνίδι.");
                        });
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    busy(false);
                    status.setText("Αποτυχία query: " + e.getClass().getSimpleName() +
                            " — " + e.getMessage() +
                            "\nΈλεγξε ότι το PC firewall επιτρέπει UDP query στο LAN.");
                });
            }
        });
    }

    @Override protected void onDestroy() {
        networkWorker.shutdownNow();
        super.onDestroy();
    }
}
