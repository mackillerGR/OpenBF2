package com.mackillergr.bf2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.graphics.Color;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.mackillergr.bf2.lan.LanJoinArgs;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Stage 3 integrated menu-first + LAN launcher for the user's test13 native libraries.
 *  Package name for this developer build differs from the user's installed test13. */
public final class LauncherActivity extends Activity {
    private static final int PICK_LAN_SERVER = 100;
    private EditText modPath, playerName, serverAddress, queryPort;
    private TextView status;
    private SharedPreferences prefs;
    private boolean turnip = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("bf2_stage3", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(15, 23, 35));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = dp(18);
        content.setPadding(p, p, p, p);
        scroll.addView(content);

        label(content, "Battlefield 2 — mackillerGR", 23);
        label(content, "Stage 3: αρχικό μενού, αναζήτηση LAN και direct IP. Δεν έχει επιβεβαιωθεί ακόμη gameplay από Android σε PC.", 14);
        label(content, "Φάκελος mods/bf2 (απόλυτο path)", 15);
        File externalRoot = getExternalFilesDir(null);
        String base = new File(externalRoot != null ? externalRoot : getFilesDir(),
                "Game Files/mods/bf2").getAbsolutePath();
        modPath = field(content, prefs.getString("modpath", base), false);
        label(content, "Όνομα παίκτη", 15);
        playerName = field(content, prefs.getString("player", "mackillerGR"), false);
        label(content, "LAN PC Server (IP:gameport)", 15);
        serverAddress = field(content, prefs.getString("server", "192.168.1.100:16567"), false);
        label(content, "Query port (για LAN discovery, συνήθως 29900)", 15);
        queryPort = field(content, prefs.getString("queryport", "29900"), true);

        Button driver = button(content, "Vulkan driver: system (πάτησε για Turnip)");
        driver.setOnClickListener(v -> {
            turnip = !turnip;
            driver.setText(turnip ? "Vulkan driver: turnip (πάτησε για system)" :
                    "Vulkan driver: system (πάτησε για Turnip)");
        });
        status = label(content, "", 14);
        button(content, "Έλεγχος αρχείων παιχνιδιού").setOnClickListener(v -> checkAssets());
        button(content, "Έναρξη στο αυθεντικό μενού PC (--menu)")
                .setOnClickListener(v -> startGame(true));
        button(content, "Αναζήτηση LAN servers").setOnClickListener(v -> {
            int qp;
            try { qp = Integer.parseInt(queryPort.getText().toString().trim()); }
            catch (NumberFormatException e) { status.setText("Λάθος query port."); return; }
            if (qp < 1 || qp > 65535) { status.setText("Λάθος query port."); return; }
            remember();
            Intent go = new Intent(this, LanBrowserActivity.class);
            go.putExtra("queryPort", qp);
            startActivityForResult(go, PICK_LAN_SERVER);
        });
        button(content, "Σύνδεση στο επιλεγμένο LAN server (--connect)")
                .setOnClickListener(v -> startGame(false));
        label(content, "Προσοχή: το LAN query στη θύρα 29900 δεν αποδεικνύει ότι η μηχανή μπορεί να ολοκληρώσει τη σύνδεση gameplay στη θύρα 16567.", 13);
        setContentView(scroll);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private TextView label(LinearLayout root, String text, int sp) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(sp);
        v.setPadding(0, dp(6), 0, dp(6)); root.addView(v); return v;
    }
    private EditText field(LinearLayout root, String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setText(value); e.setTextColor(Color.WHITE); e.setSingleLine(true);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        root.addView(e); return e;
    }
    private Button button(LinearLayout root, String text) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(text);
        root.addView(b); return b;
    }
    private void remember() {
        prefs.edit()
                .putString("modpath", modPath.getText().toString().trim())
                .putString("player", playerName.getText().toString().trim())
                .putString("server", serverAddress.getText().toString().trim())
                .putString("queryport", queryPort.getText().toString().trim())
                .apply();
    }
    private List<String> missingAssets() {
        File dir = new File(modPath.getText().toString().trim());
        String[] names = {"ClientArchives.con", "Objects_client.zip", "Common_client.zip",
                "Menu_client.zip", "Fonts_client.zip", "Shaders_client.zip", "Booster_client.zip"};
        List<String> missing = new ArrayList<>();
        if (!dir.isDirectory()) { missing.add("δεν υπάρχει ο φάκελος " + dir); return missing; }
        for (String filename : names) {
            File f = new File(dir, filename);
            if (!f.isFile() || f.length() == 0) missing.add(filename);
        }
        return missing;
    }
    private void checkAssets() {
        List<String> missing = missingAssets();
        status.setText(missing.isEmpty() ? "OK: τα 6 ZIP και ClientArchives.con βρέθηκαν. Δεν σημαίνει ότι ο engine φορτώνει." :
                "Λείπουν:\n" + String.join("\n", missing));
    }
    private void startGame(boolean menu) {
        remember();
        List<String> missing = missingAssets();
        if (!missing.isEmpty()) {
            status.setText("Δεν ξεκινάω χωρίς τα archives:\n" + String.join("\n", missing));
            return;
        }
        File main = new File(getApplicationInfo().nativeLibraryDir, "libmain.so");
        if (!main.isFile()) {
            status.setText("Λείπει το libmain.so. Τρέξε πρώτα το script προετοιμασίας των libraries.");
            return;
        }
        String[] args;
        try {
            String dir = modPath.getText().toString().trim();
            String name = playerName.getText().toString().trim();
            String lib = getApplicationInfo().nativeLibraryDir;
            String d = turnip ? "turnip" : "system";
            if (menu) {
                args = GameLaunchPlan.forMenu(dir, lib, 1280, 720, name, d);
            } else {
                String endpoint = serverAddress.getText().toString().trim();
                int sep = endpoint.lastIndexOf(':');
                if (sep < 0) throw new IllegalArgumentException("Βάλε IP:gameport");
                String ip = endpoint.substring(0, sep);
                int port = Integer.parseInt(endpoint.substring(sep + 1));
                if (!LanJoinArgs.isIPv4(ip)) throw new IllegalArgumentException("Μη έγκυρη IPv4");
                args = GameLaunchPlan.forLan(dir, lib, 1280, 720, name, d, ip, port);
            }
        } catch (IllegalArgumentException e) {
            status.setText("Άκυρες ρυθμίσεις: " + e.getMessage());
            return;
        }
        Intent launch = new Intent(this, GameActivity.class);
        launch.putExtra("args", args);
        launch.putExtra("touch", false); // Test13 overlay not yet reconstructed; use SDL input/controller.
        status.setText(menu ? "Ξεκινάω --menu..." : "Ξεκινάω --connect... (όχι επιβεβαιωμένο multiplayer)");
        startActivity(launch);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_LAN_SERVER && result == RESULT_OK && data != null) {
            String ip = data.getStringExtra("ip");
            int port = data.getIntExtra("gamePort", 0);
            if (LanJoinArgs.isIPv4(ip) && port >= 1 && port <= 65535) {
                serverAddress.setText(ip + ":" + port);
                status.setText("Επιλέχθηκε " + ip + ":" + port + ". Πάτησε Σύνδεση για να δοκιμάσεις.");
                remember();
            }
        }
    }
}
