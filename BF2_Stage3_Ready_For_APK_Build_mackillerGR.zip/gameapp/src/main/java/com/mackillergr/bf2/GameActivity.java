package com.mackillergr.bf2;

import android.os.Bundle;
import android.util.Log;
import org.libsdl.app.SDLActivity;

/** Stage 3: real SDL entry point fed by the integrated launcher.
 *  Native BF2 playback/connect not verified without device logs. */
public final class GameActivity extends SDLActivity {
    private static final String TAG = "BF2Stage3";

    @Override protected String[] getLibraries() {
        // Original test13 DEX, GameActivity.getLibraries(): filled-new-array/range v0..v5.
        // Keep 'main' last; SDLActivity's default getMainSharedObject() uses last entry.
        return new String[] {"c++_shared", "SDL3", "dice_py", "dxvk_d3d9", "vkd3d-shader", "main"};
    }

    @Override protected String[] getArguments() {
        String[] args = getIntent().getStringArrayExtra("args");
        return args == null ? new String[0] : args.clone();
    }

    @Override public void onCreate(Bundle state) {
        String[] args = getIntent().getStringArrayExtra("args");
        // Always call Activity.onCreate before finish() to avoid SuperNotCalledException.
        if (args == null || args.length == 0) {
            Log.e(TAG, "No arguments supplied; refusing game start");
            super.onCreate(state);
            finish();
            return;
        }
        // Only log selected mode; path/player may be private, CD key must never be logged.
        String mode = "UNKNOWN";
        for (String a : args) {
            if ("--menu".equals(a)) mode = "MENU";
            if ("--connect".equals(a)) mode = "DIRECT_LAN";
        }
        Log.i(TAG, "Launching native BF2: " + mode + " with " + args.length + " arguments");
        super.onCreate(state);
        // TouchOverlay from test13 is not yet recovered. SDL input is provided by SDLActivity.
    }
}
