package com.mackillergr.bf2;

import com.mackillergr.bf2.lan.LanJoinArgs;
import java.util.ArrayList;
import java.util.List;

/** Exact launch-option *names* recovered from the user's test13 DEX.
 *  This does not prove the native engine implements their complete semantics. */
public final class GameLaunchPlan {
    private GameLaunchPlan() {}

    public static String[] forMenu(String modDir, String libDir, int width,
                                   int height, String player, String driver) {
        List<String> args = common(modDir, libDir, width, height, player, driver);
        args.add("--menu");
        return args.toArray(new String[0]);
    }

    public static String[] forLan(String modDir, String libDir, int width,
                                  int height, String player, String driver,
                                  String ipv4, int port) {
        List<String> args = common(modDir, libDir, width, height, player, driver);
        String[] safe = LanJoinArgs.directIp(args.toArray(new String[0]), ipv4, port);
        return safe;
    }

    static List<String> common(String modDir, String libDir, int width,
                               int height, String player, String driver) {
        if (modDir == null || !modDir.startsWith("/") || modDir.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Invalid absolute BF2 mod path");
        if (libDir == null || !libDir.startsWith("/") || libDir.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Invalid native library path");
        if (width < 640 || width > 7680 || height < 480 || height > 4320)
            throw new IllegalArgumentException("Invalid resolution");
        if (player == null || player.trim().isEmpty() || player.length() > 32 || player.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Invalid player name");
        if (!"system".equals(driver) && !"turnip".equals(driver))
            throw new IllegalArgumentException("Driver must be system or turnip");
        List<String> args = new ArrayList<>();
        add(args, "--mod", modDir);
        add(args, "--width", Integer.toString(width));
        add(args, "--height", Integer.toString(height));
        add(args, "--name", player);
        add(args, "--libdir", libDir);
        add(args, "--driver", driver);
        return args;
    }
    private static void add(List<String> target, String flag, String value) {
        target.add(flag); target.add(value);
    }
}
